import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT || 8080);
const ROOT = path.resolve(process.argv[2] || 'spil');
const DATA_FILE = path.resolve('data.json');
const DEVELOPERS = ['MD-DEV'];
const BAN_MS = 24 * 60 * 60 * 1000;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webm': 'video/webm',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon'
};

let db = { users: [], clips: [], reports: [], nextClip: 1 };
try {
  db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
} catch (e) {
  /* first run */
}

function persist() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  } catch (e) {
    console.error('kunne ikke gemme data', e.message);
  }
}

function findUser(name) {
  return db.users.find((u) => u.name.toLowerCase() === String(name || '').toLowerCase());
}

function byToken(token) {
  if (!token) return null;
  return db.users.find((u) => u.token === token) || null;
}

function publicUser(u) {
  return {
    name: u.name,
    coins: u.coins,
    up: u.up,
    trail: u.trail,
    owns: u.owns,
    isAdmin: !!u.isAdmin,
    dev: DEVELOPERS.includes(u.name),
    infDmg: !!u.infDmg,
    infHp: !!u.infHp,
    friends: u.friends || []
  };
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 1e6) req.destroy();
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
}

function tokenOf(req) {
  const h = req.headers.authorization || '';
  return h.replace(/^Bearer\s+/i, '');
}

function staticFile(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath.split('?')[0]);
  if (rel === '/' || rel === '') rel = '/power-brawl/';
  if (rel.endsWith('/')) rel += 'index.html';
  const filePath = path.join(ROOT, rel);
  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403);
    res.end('forbidden');
    return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('not found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, { 'content-type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;

  if (!p.startsWith('/api/')) {
    staticFile(req, res, p);
    return;
  }

  const body = req.method === 'POST' ? await readBody(req) : {};
  let user = byToken(tokenOf(req));
  if (user && user.banned) {
    if (user.bannedUntil && Date.now() >= user.bannedUntil) {
      user.banned = false;
      user.bannedUntil = 0;
      persist();
    } else {
      user = null;
    }
  }

  // ---- health ----
  if (p === '/api/health') {
    send(res, 200, { ok: true, players: db.users.length });
    return;
  }

  // ---- login / register ----
  if (p === '/api/login' && req.method === 'POST') {
    const name = String(body.name || '').trim().toUpperCase().slice(0, 12);
    if (name.length < 2) {
      send(res, 400, { error: 'name too short' });
      return;
    }
    let u = findUser(name);
    if (u) u.isAdmin = DEVELOPERS.includes(u.name) || !!u.grantedAdmin;
    if (u && !u.token) {
      u.token = crypto.randomBytes(12).toString('hex');
      persist();
    }
    if (u && u.banned) {
      if (u.bannedUntil && Date.now() >= u.bannedUntil) {
        u.banned = false;
        u.bannedUntil = 0;
        persist();
      } else {
        const mins = Math.max(1, Math.ceil(((u.bannedUntil || 0) - Date.now()) / 60000));
        send(res, 403, { error: 'banned', minutes: mins });
        return;
      }
    }
    if (!u) {
      u = {
        name,
        token: crypto.randomBytes(12).toString('hex'),
        coins: 100,
        up: { dmg: 0, hp: 0, spd: 0 },
        trail: '',
        owns: [],
        friends: [],
        isAdmin: DEVELOPERS.includes(name),
        likes: [],
        createdAt: Date.now()
      };
      db.users.push(u);
      persist();
    }
    send(res, 200, { token: u.token, user: publicUser(u) });
    return;
  }

  if (p === '/api/me') {
    if (!user) {
      send(res, 401, { error: 'no user' });
      return;
    }
    send(res, 200, { user: publicUser(user) });
    return;
  }

  if (p === '/api/save' && req.method === 'POST') {
    if (!user) {
      send(res, 401, { error: 'no user' });
      return;
    }
    if (typeof body.coins === 'number') user.coins = Math.max(0, Math.round(body.coins));
    if (body.up && typeof body.up === 'object') {
      user.up = {
        dmg: Math.max(0, Math.min(5, body.up.dmg | 0)),
        hp: Math.max(0, Math.min(5, body.up.hp | 0)),
        spd: Math.max(0, Math.min(5, body.up.spd | 0))
      };
    }
    if (typeof body.trail === 'string') user.trail = body.trail;
    if (Array.isArray(body.owns)) user.owns = body.owns.slice(0, 20);
    if (typeof body.infDmg === 'boolean') user.infDmg = body.infDmg;
    if (typeof body.infHp === 'boolean') user.infHp = body.infHp;
    persist();
    send(res, 200, { user: publicUser(user) });
    return;
  }

  // ---- friends ----
  if (p === '/api/friends' && req.method === 'POST') {
    if (!user) {
      send(res, 401, { error: 'no user' });
      return;
    }
    const other = findUser(body.name);
    if (!other || other.name === user.name) {
      send(res, 404, { error: 'player not found' });
      return;
    }
    if (!user.friends.includes(other.name)) user.friends.push(other.name);
    if (!other.friends.includes(user.name)) other.friends.push(user.name);
    persist();
    send(res, 200, { ok: true, friends: user.friends });
    return;
  }

  if (p === '/api/players') {
    const q = String(url.searchParams.get('q') || '').toLowerCase();
    const list = db.users
      .filter((u) => u.name.toLowerCase().includes(q))
      .slice(0, 20)
      .map((u) => ({ name: u.name, coins: u.coins, admin: !!u.isAdmin }));
    send(res, 200, { players: list });
    return;
  }

  // ---- clips ----
  if (p === '/api/clips' && req.method === 'GET') {
    const clips = db.clips.map((c) => ({
      id: c.id,
      title: c.title,
      by: c.by,
      kills: c.kills,
      color: c.color,
      likes: c.likes.length
    }));
    send(res, 200, { clips, liked: user ? user.likes : [] });
    return;
  }

  if (p === '/api/clips' && req.method === 'POST') {
    if (!user) {
      send(res, 401, { error: 'no user' });
      return;
    }
    const clip = {
      id: 'c' + db.nextClip++,
      title: String(body.title || 'My match').slice(0, 40),
      by: user.name,
      kills: Math.max(0, body.kills | 0),
      color: String(body.color || '#7cc0ff').slice(0, 16),
      likes: [],
      at: Date.now()
    };
    db.clips.push(clip);
    persist();
    send(res, 200, { clip });
    return;
  }

  const likeMatch = p.match(/^\/api\/clips\/([^/]+)\/like$/);
  if (likeMatch && req.method === 'POST') {
    if (!user) {
      send(res, 401, { error: 'no user' });
      return;
    }
    const clip = db.clips.find((c) => c.id === likeMatch[1]);
    if (!clip) {
      send(res, 404, { error: 'no clip' });
      return;
    }
    const i = clip.likes.indexOf(user.name);
    if (i >= 0) {
      clip.likes.splice(i, 1);
      user.likes = user.likes.filter((x) => x !== clip.id);
    } else {
      clip.likes.push(user.name);
      if (!user.likes.includes(clip.id)) user.likes.push(clip.id);
    }
    persist();
    send(res, 200, { likes: clip.likes.length });
    return;
  }

  if (p === '/api/report' && req.method === 'POST') {
    if (!user) {
      send(res, 401, { error: 'no user' });
      return;
    }
    db.reports = db.reports || [];
    db.reports.push({ by: user.name, name: String(body.name || '').slice(0, 12), at: Date.now() });
    persist();
    send(res, 200, { ok: true });
    return;
  }

  // ---- admin ----
  if (p.startsWith('/api/admin/')) {
    if (!user || !user.isAdmin) {
      send(res, 403, { error: 'not admin' });
      return;
    }
    if (p === '/api/admin/reports') {
      send(res, 200, { reports: (db.reports || []).slice(-50).reverse() });
      return;
    }
    if (p === '/api/admin/users') {
      send(res, 200, {
        users: db.users.map((u) => ({
          name: u.name,
          coins: u.coins,
          up: u.up,
          trail: u.trail,
          admin: !!u.isAdmin,
          banned: !!u.banned,
          bannedUntil: u.bannedUntil || 0,
          friends: (u.friends || []).length
        }))
      });
      return;
    }
    if (p === '/api/admin/coins' && req.method === 'POST') {
      const target = body.name ? findUser(body.name) : user;
      if (!target) {
        send(res, 404, { error: 'no user' });
        return;
      }
      target.coins += Math.round(Number(body.amount) || 0);
      if (target.coins < 0) target.coins = 0;
      persist();
      send(res, 200, { ok: true, name: target.name, coins: target.coins });
      return;
    }
    if (p === '/api/admin/ban' && req.method === 'POST') {
      const target = findUser(body.name);
      if (!target) {
        send(res, 404, { error: 'no user' });
        return;
      }
      if (target.name === user.name) {
        send(res, 400, { error: 'cannot ban yourself' });
        return;
      }
      if (DEVELOPERS.includes(target.name)) {
        send(res, 403, { error: 'cannot ban the developer' });
        return;
      }
      target.banned = body.banned === false ? false : true;
      target.bannedUntil = target.banned ? Date.now() + BAN_MS : 0;
      if (target.banned) target.token = '';
      persist();
      send(res, 200, { ok: true, name: target.name, banned: !!target.banned, until: target.bannedUntil });
      return;
    }
    if (p === '/api/admin/makeadmin' && req.method === 'POST') {
      const target = findUser(body.name);
      if (!target) {
        send(res, 404, { error: 'no user' });
        return;
      }
      if (!user.isAdmin) {
        send(res, 403, { error: 'not admin' });
        return;
      }
      if (DEVELOPERS.includes(target.name) && body.on === false) {
        send(res, 403, { error: 'cannot remove the developer' });
        return;
      }
      target.grantedAdmin = body.on === false ? false : true;
      target.isAdmin = DEVELOPERS.includes(target.name) || !!target.grantedAdmin;
      persist();
      send(res, 200, { ok: true, name: target.name });
      return;
    }
    if (p === '/api/admin/edit' && req.method === 'POST') {
      const target = findUser(body.name);
      if (!target) {
        send(res, 404, { error: 'no user' });
        return;
      }
      if (typeof body.coins === 'number') target.coins = Math.max(0, Math.round(body.coins));
      if (body.up && typeof body.up === 'object') {
        target.up = {
          dmg: Math.max(0, Math.min(5, body.up.dmg | 0)),
          hp: Math.max(0, Math.min(5, body.up.hp | 0)),
          spd: Math.max(0, Math.min(5, body.up.spd | 0))
        };
      }
      if (typeof body.infDmg === 'boolean') target.infDmg = body.infDmg;
      if (typeof body.infHp === 'boolean') target.infHp = body.infHp;
      if (typeof body.trail === 'string') {
        target.trail = body.trail;
        target.owns = target.owns || [];
        if (body.trail && target.owns.indexOf(body.trail) < 0) target.owns.push(body.trail);
      }
      persist();
      send(res, 200, { user: publicUser(target) });
      return;
    }
  }

  send(res, 404, { error: 'unknown' });
});

server.listen(PORT, process.env.HOST || '0.0.0.0', () => {
  const first = db.users.length === 0;
  console.log('Marvel Dominator server on http://127.0.0.1:' + PORT + '/power-brawl/');
  console.log(first ? 'First player to sign up becomes ADMIN.' : 'Players: ' + db.users.length);
});
