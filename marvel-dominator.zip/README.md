﻿# Marvel Dominator

Et 2D browser-spil. Alt ligger i én fil: index.html

## Spil det
Åbn linket til GitHub Pages, eller åbn index.html i din browser.

## Helte
Hulk, Spider-Man, Dr. Strange, Iron Man, Mantis, Groot, Star-Lord, Deadpool og Wolverine.

## Baner
New York, Tower, Earth og Space.

## Regler
- 5 mod 5
- 5 minutter
- flest drab vinder
- infinity stones naar der er 20 sekunder tilbage

## Kontrol
WASD ga, mus sigt, klik angrib, SPACE og SHIFT evner, F auto-sigte.
